import { useState } from 'react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { User } from '../App';
import { Building2, Lock, UserCheck, Shield } from 'lucide-react';

interface LoginPageProps {
  onLogin: (user: User) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate login process
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Mock authentication - in real app, this would be handled by backend
    if (username && password) {
      const user: User = {
        id: '1',
        username: username,
        puskesmas: 'Puskesmas Sukmajaya',
        location: 'Kota Depok'
      };
      onLogin(user);
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 pt-8">
      <Card className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <Building2 className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">SPASI</h1>
          <p className="text-muted-foreground">Sistem Pencatatan Kasus LP3I</p>
          <div className="flex items-center justify-center gap-2 mt-2 text-sm text-muted-foreground">
            <Building2 className="w-4 h-4" />
            <span>Puskesmas Digital Indonesia</span>
          </div>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="username" className="flex items-center gap-2">
              <UserCheck className="w-4 h-4" />
              Username
            </Label>
            <Input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Masukkan username"
              className="spasi-input"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Password
            </Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Masukkan password"
              className="spasi-input"
              required
            />
          </div>

          <Button
            type="submit"
            disabled={isLoading || !username || !password}
            className="w-full spasi-button"
          >
            {isLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin"></div>
                Memuat...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <UserCheck className="w-4 h-4" />
                Masuk
              </div>
            )}
          </Button>
        </form>

        <div className="mt-8 p-4 bg-muted rounded-lg">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Shield className="w-4 h-4 flex-shrink-0" />
            <div>
              <p>Akun dibuat oleh admin sistem.</p>
              <p>Hubungi admin jika ada masalah login.</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}