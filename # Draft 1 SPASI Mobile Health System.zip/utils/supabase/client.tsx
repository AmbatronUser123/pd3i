import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './info';

const supabaseUrl = `https://${projectId}.supabase.co`;
const supabase = createClient(supabaseUrl, publicAnonKey);

export interface KasusMR01 {
  id?: string;
  disease: string;
  form: string;
  status: 'draft' | 'submitted';
  user_id: string;
  
  // Info Pelapor
  pelapor_nama?: string;
  pelapor_jabatan?: string;
  pelapor_telp?: string;
  pelapor_email?: string;
  tanggal_lapor?: string;
  
  // Info Kasus
  pasien_nama?: string;
  pasien_nik?: string;
  pasien_tgl_lahir?: string;
  pasien_umur?: string;
  pasien_jk?: string;
  pasien_alamat?: string;
  pasien_rt_rw?: string;
  pasien_kelurahan?: string;
  pasien_kecamatan?: string;
  
  // Info Klinis
  tanggal_onset?: string;
  gejala_demam?: string;
  gejala_ruam?: string;
  gejala_batuk?: string;
  gejala_pilek?: string;
  gejala_mata_merah?: string;
  gejala_lain?: string;
  
  // Riwayat Pengobatan
  sedang_dirawat?: string;
  rumah_sakit?: string;
  tanggal_dirawat?: string;
  obat_yang_diminum?: string;
  riwayat_rawat_inap?: string;
  
  // Riwayat Vaksinasi
  status_imunisasi?: string;
  vaksin_terakhir?: string;
  tanggal_vaksin_terakhir?: string;
  tempat_imunisasi?: string;
  catatan_imunisasi?: string;
  
  // Info Epidemiologis
  kontak_kasus_lain?: string;
  bepergian_2_minggu?: string;
  tempat_bepergian?: string;
  tanggal_bepergian?: string;
  sumber_infeksi?: string;
  
  // Info Spesimen
  spesimen_diambil?: string;
  jenis_spesimen?: string;
  tanggal_pengambilan?: string;
  tempat_pemeriksaan?: string;
  hasil_lab?: string;
  
  // Info Akhir Kasus
  klasifikasi_akhir?: string;
  kondisi_akhir?: string;
  tanggal_meninggal?: string;
  penyebab_kematian?: string;
  tindak_lanjut?: string;
  
  // Info Kontak Erat
  jumlah_kontak?: string;
  kontak_keluarga?: string;
  kontak_sekolah?: string;
  kontak_lain?: string;
  catatan_kontak?: string;
  
  // Info Pelaksana
  petugas_nama?: string;
  petugas_nip?: string;
  petugas_jabatan?: string;
  tanggal_pengisian?: string;
  tanda_tangan?: string;
  koordinat_lokasi?: string;
  
  created_at?: string;
  updated_at?: string;
  last_modified?: string;
  pending_sync?: boolean;
}

// Supabase table operations for case data
export const kasusMR01Operations = {
  // Generate a proper string-based ID that won't cause integer overflow
  generateId(): string {
    return `case_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  },

  // Convert form data object to flat table structure
  convertFormDataToTableData(formData: Record<string, any>, baseData: Partial<KasusMR01>): KasusMR01 {
    return {
      ...baseData,
      // Map all form fields directly to table columns
      pelapor_nama: formData.pelapor_nama || '',
      pelapor_jabatan: formData.pelapor_jabatan || '',
      pelapor_telp: formData.pelapor_telp || '',
      pelapor_email: formData.pelapor_email || '',
      tanggal_lapor: formData.tanggal_lapor || '',
      
      pasien_nama: formData.pasien_nama || '',
      pasien_nik: formData.pasien_nik || '',
      pasien_tgl_lahir: formData.pasien_tgl_lahir || '',
      pasien_umur: formData.pasien_umur || '',
      pasien_jk: formData.pasien_jk || '',
      pasien_alamat: formData.pasien_alamat || '',
      pasien_rt_rw: formData.pasien_rt_rw || '',
      pasien_kelurahan: formData.pasien_kelurahan || '',
      pasien_kecamatan: formData.pasien_kecamatan || '',
      
      tanggal_onset: formData.tanggal_onset || '',
      gejala_demam: formData.gejala_demam || '',
      gejala_ruam: formData.gejala_ruam || '',
      gejala_batuk: formData.gejala_batuk || '',
      gejala_pilek: formData.gejala_pilek || '',
      gejala_mata_merah: formData.gejala_mata_merah || '',
      gejala_lain: formData.gejala_lain || '',
      
      sedang_dirawat: formData.sedang_dirawat || '',
      rumah_sakit: formData.rumah_sakit || '',
      tanggal_dirawat: formData.tanggal_dirawat || '',
      obat_yang_diminum: formData.obat_yang_diminum || '',
      riwayat_rawat_inap: formData.riwayat_rawat_inap || '',
      
      status_imunisasi: formData.status_imunisasi || '',
      vaksin_terakhir: formData.vaksin_terakhir || '',
      tanggal_vaksin_terakhir: formData.tanggal_vaksin_terakhir || '',
      tempat_imunisasi: formData.tempat_imunisasi || '',
      catatan_imunisasi: formData.catatan_imunisasi || '',
      
      kontak_kasus_lain: formData.kontak_kasus_lain || '',
      bepergian_2_minggu: formData.bepergian_2_minggu || '',
      tempat_bepergian: formData.tempat_bepergian || '',
      tanggal_bepergian: formData.tanggal_bepergian || '',
      sumber_infeksi: formData.sumber_infeksi || '',
      
      spesimen_diambil: formData.spesimen_diambil || '',
      jenis_spesimen: formData.jenis_spesimen || '',
      tanggal_pengambilan: formData.tanggal_pengambilan || '',
      tempat_pemeriksaan: formData.tempat_pemeriksaan || '',
      hasil_lab: formData.hasil_lab || '',
      
      klasifikasi_akhir: formData.klasifikasi_akhir || '',
      kondisi_akhir: formData.kondisi_akhir || '',
      tanggal_meninggal: formData.tanggal_meninggal || '',
      penyebab_kematian: formData.penyebab_kematian || '',
      tindak_lanjut: formData.tindak_lanjut || '',
      
      jumlah_kontak: formData.jumlah_kontak || '',
      kontak_keluarga: formData.kontak_keluarga || '',
      kontak_sekolah: formData.kontak_sekolah || '',
      kontak_lain: formData.kontak_lain || '',
      catatan_kontak: formData.catatan_kontak || '',
      
      petugas_nama: formData.petugas_nama || '',
      petugas_nip: formData.petugas_nip || '',
      petugas_jabatan: formData.petugas_jabatan || '',
      tanggal_pengisian: formData.tanggal_pengisian || '',
      tanda_tangan: formData.tanda_tangan || '',
      koordinat_lokasi: formData.koordinat_lokasi || ''
    } as KasusMR01;
  },

  // Convert table data back to form data object for backward compatibility
  convertTableDataToFormData(tableData: KasusMR01): Record<string, any> {
    const formData: Record<string, any> = {};
    
    // Map all table columns back to form fields
    Object.keys(tableData).forEach(key => {
      if (!['id', 'disease', 'form', 'status', 'user_id', 'created_at', 'updated_at', 'last_modified', 'pending_sync'].includes(key)) {
        formData[key] = tableData[key as keyof KasusMR01];
      }
    });
    
    return formData;
  },

  async insert(data: { disease: string; form: string; status: 'draft' | 'submitted'; user_id: string; formData: Record<string, any> }) {
    try {
      const tableData = this.convertFormDataToTableData(data.formData, {
        disease: data.disease,
        form: data.form,
        status: data.status,
        user_id: data.user_id,
        last_modified: new Date().toISOString()
      });

      // Make server request to create new case
      const response = await fetch(`${supabaseUrl}/functions/v1/make-server-b2c9964a/kasus-mr01`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ 
          action: 'create', 
          data: tableData 
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }

      const result = await response.json();
      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    } catch (error) {
      console.error('Error inserting case:', error);
      throw error;
    }
  },

  async update(id: string, data: { disease?: string; form?: string; status?: 'draft' | 'submitted'; user_id?: string; formData?: Record<string, any> }) {
    try {
      let updateData: Partial<KasusMR01> = {
        last_modified: new Date().toISOString()
      };

      // If formData is provided, convert it to table structure
      if (data.formData) {
        const tableData = this.convertFormDataToTableData(data.formData, {
          disease: data.disease,
          form: data.form,
          status: data.status,
          user_id: data.user_id
        });
        updateData = { ...updateData, ...tableData };
      } else {
        // Otherwise, update only the provided fields
        if (data.disease) updateData.disease = data.disease;
        if (data.form) updateData.form = data.form;
        if (data.status) updateData.status = data.status;
        if (data.user_id) updateData.user_id = data.user_id;
      }

      // Make server request to update data
      const response = await fetch(`${supabaseUrl}/functions/v1/make-server-b2c9964a/kasus-mr01`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ 
          action: 'update', 
          id,
          data: updateData 
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }

      const result = await response.json();
      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    } catch (error) {
      console.error('Error updating case:', error);
      throw error;
    }
  },

  async delete(id: string) {
    try {
      // Make server request to delete data
      const response = await fetch(`${supabaseUrl}/functions/v1/make-server-b2c9964a/kasus-mr01`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ 
          action: 'delete', 
          id 
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }

      const result = await response.json();
      if (result.error) {
        throw new Error(result.error);
      }

      return true;
    } catch (error) {
      console.error('Error deleting case:', error);
      throw error;
    }
  },

  async getById(id: string): Promise<KasusMR01 | null> {
    try {
      // Make server request to get data
      const response = await fetch(`${supabaseUrl}/functions/v1/make-server-b2c9964a/kasus-mr01`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ 
          action: 'get', 
          id 
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }

      const result = await response.json();
      if (result.error) {
        throw new Error(result.error);
      }

      return result.data || null;
    } catch (error) {
      console.error('Error getting case by ID:', error);
      // Return null for not found, don't throw
      return null;
    }
  },

  async getByUser(userId: string): Promise<KasusMR01[]> {
    try {
      // Make server request to get data by user
      const response = await fetch(`${supabaseUrl}/functions/v1/make-server-b2c9964a/kasus-mr01`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ 
          action: 'getByUser', 
          data: { userId } 
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }

      const result = await response.json();
      if (result.error) {
        throw new Error(result.error);
      }

      return result.data || [];
    } catch (error) {
      console.error('Error getting cases by user:', error);
      return [];
    }
  },

  async getAllCases(): Promise<KasusMR01[]> {
    try {
      // Make server request to get all case data
      const response = await fetch(`${supabaseUrl}/functions/v1/make-server-b2c9964a/kasus-mr01`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ 
          action: 'getAll' 
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }

      const result = await response.json();
      if (result.error) {
        throw new Error(result.error);
      }

      return result.data || [];
    } catch (error) {
      console.error('Error getting all cases:', error);
      return [];
    }
  }
};

export { supabase };